//
//  ViewController.m
//  return
//
//  Created by apple on 2017/9/29.
//  Copyright © 2017年 yangchao. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //1:关于break  运行下边的程序,将看到i循环到2时候就结束 ,当i等于2时,循环体内遇到break语句,程序跳出循环
    // break用于完全结束一个循环,跳出循环体,不管是那种循环,一旦在循环体中遇到break,系统将完全结束该循环,开始执行循环后边的代码
    
    for (int i = 0; i<4; i++) {
        
//        NSLog(@"当前i的值是:%d",i);
        if (i ==2 ) {
            
            //执行该语句时结束循环
            break;
        }
    }
    
    //2: continue只是中止本次循环,接着开始下一次循环
    for (int i = 0; i<5; i++) {
        
        NSLog(@"当前i的值是:%d",i);
        if (i >=2) {
            
            continue;//忽略本次循环剩下的语句
        }
        NSLog(@"continue后输出的语句");
        
    }

    //3: .关于return
    //return并不是专门用于结束循环结构的关键字眼
    //return是直接结束整个函数,不管这个return处于多少层循环之内
    
    for (int i = 0; i<5; i++) {
        
        NSLog(@"当前i的值是:%d",i);
        if (i ==2) {
            
            return ;
        }
        NSLog(@"continue后输出的语句");

    }
    NSLog(@"不执行");
}


@end
