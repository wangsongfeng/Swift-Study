//
//  HttpTool.swift
//  16-Swift 闭包的用法
//
//  Created by apple on 2017/10/12.
//  Copyright © 2017年 yangchao. All rights reserved.
//

import UIKit

class HttpTool: NSObject {
    
    var callBack : ((_ jsonData : String) -> ())?
    
//闭包： (参数列表) -> (返回值类型)
    func loadData(callBack : @escaping (_ jasnData : String) -> ()) -> Void {
        
        self.callBack=callBack
        //注意这里 调用self ，，在其他类里，在调用self 容易 引起循环引用
       callBack("wang")
    }
    
    
}
