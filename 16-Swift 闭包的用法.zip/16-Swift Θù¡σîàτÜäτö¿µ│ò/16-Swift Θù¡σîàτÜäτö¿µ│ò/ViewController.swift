//
//  ViewController.swift
//  16-Swift 闭包的用法
//
//  Created by apple on 2017/10/12.
//  Copyright © 2017年 yangchao. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
let httpTool=HttpTool()
        
        httpTool.loadData { (string) in
            print(string)
        }
    }

}

