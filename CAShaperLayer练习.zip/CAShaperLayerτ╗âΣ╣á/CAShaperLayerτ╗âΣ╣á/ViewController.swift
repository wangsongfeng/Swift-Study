//
//  ViewController.swift
//  CAShaperLayer练习
//
//  Created by apple on 2017/10/9.
//  Copyright © 2017年 yangchao. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    setAnimationLayer()
        
    }

    func setAnimationLayer() -> Void {
        let finalSize = CGSize.init(width: self.view.frame.size.width, height: self.view.frame.size.height)
        let layerHeight = finalSize.height*0.2
        let layer = CAShapeLayer()
        let bezier = UIBezierPath()
        bezier.move(to: CGPoint.init(x: 0, y: finalSize.height-layerHeight))
        
        bezier.addLine(to: CGPoint.init(x: 0, y: finalSize.height-1))
        bezier.addLine(to: CGPoint.init(x: finalSize.width, y: finalSize.height-1))
        bezier.addLine(to: CGPoint.init(x: finalSize.width, y: finalSize.height-layerHeight))
        bezier.addQuadCurve(to: CGPoint.init(x: 0, y: finalSize.height-layerHeight), controlPoint: CGPoint.init(x: finalSize.width/2, y: finalSize.height-layerHeight-40))
        bezier.lineWidth=4
        layer.path=bezier.cgPath
        layer.fillColor=UIColor.red.cgColor
        layer.strokeColor=UIColor.white.cgColor
        self.view.layer.addSublayer(layer)
    }
    
    
}

