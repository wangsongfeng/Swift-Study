//
//  Movie.swift
//  01-SwiftText
//
//  Created by apple on 2017/9/27.
//  Copyright © 2017年 yangchao. All rights reserved.
//

import UIKit

class Movie: NSObject {

    var director : String
    init(name : String ,director: String) {
        self.director=director
    }
    
}
