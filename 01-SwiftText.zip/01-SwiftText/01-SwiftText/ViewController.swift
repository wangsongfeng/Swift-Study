//
//  ViewController.swift
//  01-SwiftText
//
//  Created by apple on 2017/9/27.
//  Copyright © 2017年 yangchao. All rights reserved.
//

import UIKit
let Wight = UIScreen.main.bounds.size.width
let Height = UIScreen.main.bounds.size.height
class ViewController: UIViewController {
    
    lazy var button:UIButton = {
        let btn = UIButton()
        btn.frame = CGRect(x:100, y:100, width:100, height:20)
        btn.backgroundColor = UIColor.red
        
       return btn
    }()
    override func viewDidLoad() {
        super.viewDidLoad()
//Swift类型转换浅析
        let hourlyRate = 19.5
        let hourWorld = 10
        let totalCost = hourlyRate * Double(hourWorld)
        
        print(totalCost)
        self.view.addSubview(button)
        
        let a : String? = "wang"
        guard let b = a else {
            print("a is nil")
        }
        print(b)
            
    }
    
    func cheap(person: [String: String?])  {
        guard person["id"] != nil else {
            print("没有身份证，不准进场")
            return
        }
        
    }
    
    
    

}

