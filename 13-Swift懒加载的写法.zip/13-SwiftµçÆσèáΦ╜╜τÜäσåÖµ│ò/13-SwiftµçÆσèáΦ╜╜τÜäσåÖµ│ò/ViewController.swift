//
//  ViewController.swift
//  13-Swift懒加载的写法
//
//  Created by apple on 2017/10/12.
//  Copyright © 2017年 yangchao. All rights reserved.
//

import UIKit

let ScreenWidth = UIScreen.main.bounds.size.width
let ScreenHeight = UIScreen.main.bounds.size.height

class ViewController: UIViewController {

    
/*
   private 修饰 访问级别所修饰的属性或者方法只能在当前类里访问
 */
    lazy var zyTableView : UITableView = {
        let tempTableView = UITableView()
        
        
        return tempTableView
    }()
    
    private lazy var titleView : UIView = {
        let titleViews = UIView()
        
        return titleViews
    }()
    
    fileprivate var btn : UIButton = UIButton()
    
    override func viewDidLoad() {
        super.viewDidLoad()

    
    
    }


}

class student: ViewController {



}






