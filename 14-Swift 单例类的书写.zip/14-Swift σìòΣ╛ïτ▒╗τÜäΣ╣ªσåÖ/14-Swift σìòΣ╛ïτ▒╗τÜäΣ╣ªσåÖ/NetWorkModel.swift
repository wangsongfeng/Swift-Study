//
//  NetWorkModel.swift
//  14-Swift 单例类的书写
//
//  Created by apple on 2017/10/12.
//  Copyright © 2017年 yangchao. All rights reserved.
//

import UIKit

class NetWorkModel: NSObject {

    //单例 简单写法
    
    static let netWorkModel = NetWorkModel()
    
}



