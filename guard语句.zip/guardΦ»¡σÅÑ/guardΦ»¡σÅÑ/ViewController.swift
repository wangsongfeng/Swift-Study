//
//  ViewController.swift
//  guard语句
//
//  Created by apple on 2017/9/29.
//  Copyright © 2017年 yangchao. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
//        gotoNetBar(age: 20)
//        alsoGotoNetBar(age: 15)
//        gotoWashRoom(sex: 0, money: 2)
//        alsoGotoWashRoom(sex: 1, money: 0.1)
        online(age: 20, IdCard: 1, money: 15.0)
        let min = 18
        let second = 8
        
        let timeString = String(format:"%02d:%02d", arguments:[min,second])
        print(timeString)
        let timeS = String.init(format: "%02d:%02d", arguments:[min,second])
        print(timeS)
        
    }
    //OC 方法
    func gotoNetBar(age : Int) {
        if age > 18 {
            print("可以上网")
        }else {
            print("不可以上网")
        }
    }
    
    //guard
    
    func alsoGotoNetBar (age : Int) -> Void {
        guard age > 18 else {
            print("不能上网")
            return
        }
        print("可以上网")
    }
    
    
    func gotoWashRoom(sex : Int, money : Double) -> Void {
        if sex == 1 {
            print("去男厕所")
            if money > 0.5 {
                print("可以")
            }else{
                print("不可以")
                return
            }
            
        }else{
            print("去女厕所")
            return
        }
    }
    
    func alsoGotoWashRoom(sex : Int, money : Double) -> Void {
        guard sex==1 else {
            print("去女厕所")
            return
        }
        print("男厕所")
        
        guard money > 0.5 else {
            print("钱不够")
            return
        }
        print("钱够了")
    }
    
    
    func online(age : Int,IdCard : Int, money : Double) -> Void {
        guard age >= 18 else {
            print("未满18岁不能上网")
            return
        }
        print("满18 可以上网")

        guard IdCard==1 else {
            print("没有身份证不可以上网")
            return
        }
        print("有身份证可以上网")

        guard money >= 10 else {
            print("钱不够不可以上网")
            return
        }
        print("钱够了 keyishangwng")
        
    }
    
    
}

